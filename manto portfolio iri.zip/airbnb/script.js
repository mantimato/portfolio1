$(document).ready(function() {
	$(".butonli").mouseenter(function() {
		$(".js-becomehost").show();
	});
	$(".butonli").mouseleave(function() {
		$(".js-becomehost").hide();
	});
	$(".inputbuton, .inputbuton1").click(function() {
		$(this).css({
		  "background-color": "#99ede6",
		  "border-color": "#99ede6",
		  "border-radius": "3px",
		  "color": "#007a87"});
	});
	$(".inputbuton, .inputbuton1").blur(function() {
		$(this).css({
		  "background-color": "",
		  "border-color": "",
		  "border-radius": "",
		  "color": ""});
	});
	$(".inputbuton, .inputbuton1").click(function() {
		$("#kalendorius1").show();
	});
	$(".inputbuton").click(function() {
		$(".trikampis").show();
		$(".trikampis1").hide();
	});
	$(".inputbuton1").click(function() {
		$(".trikampis1").show();
		$(".trikampis").hide();
	});
	$(document).click(function(event) { 
    if(!$(event.target).closest("#kalendorius1, .inputbuton, .inputbuton1, .trikampis, .trikampis1").length) {
        if($("#kalendorius1, .trikampis, .trikampis1").is(":visible")) {
            $("#kalendorius1, .trikampis, .trikampis1").hide();
        }
    }        
});
});