$(document).ready(function() {
	$('#nav-icon').click(function(){
		$(this).toggleClass('open');
		
	});
	
	$('.nav-icona').click(function(){
		$(".menujs").toggle(100);
		
	});
});