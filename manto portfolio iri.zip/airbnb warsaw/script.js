$(function(){
	$(".butonli").mouseenter(function() {
		$(".js-becomehost").show();
	});
	$(".butonli").mouseleave(function() {
		$(".js-becomehost").hide();
	});
	 $(".input1, .input2").datepicker();

 	    $( "#manoslider" ).slider({
      range: true,
      min: 9,
      max: 1000,
      values: [ 9, 1000 ],
      slide: function( event, ui ) {
        $( "#amount" ).val( "$" + ui.values[ 0 ] );
        $( "#amount1" ).val("$" + ui.values[ 1 ] + "+" );
      }
    });
    $( "#amount" ).val( "$" + $( "#manoslider" ).slider( "values", 0 ) );
   $( "#amount1" ).val( "$" + $( "#manoslider" ).slider( "values", 1 ) + "+" );

   

    $(".selectguest").click(function() {
		  $(".btnspan").toggleClass("btnbg");
      $(".angleup").toggle();
      $(".angledown").toggle();
      $(".guestmenu").toggle();
	});
$(document).click(function(event) { 
    if(!$(event.target).closest(".guestmenu, .selectguest").length) {
        if($(".guestmenu").is(":visible")) {
            $(".guestmenu").hide();
            $(".btnspan").removeClass("btnbg");
            $(".angleup").toggle();
            $(".angledown").toggle();
        }
    }        
});
$(".uzdaro").click(function() {
  $(".guestmenu").hide();
  $(".btnspan").removeClass("btnbg");
  $(".angleup").toggle();
  $(".angledown").toggle();
});


	
	$(".fa-question-circl").tooltip({title: "<strong>Entire home</strong><br> Listings where you have whole place to yourself<br><br><strong>Private Room</strong> Listings where you have your own room but share some common spaces<br>", html:true, placement: "right"});

	$(".onoffdivas").click(function() {
		$(this).toggleClass("keiciaspalva");
	});
	
	$(".onoffdivas").on("click", function(){
    var flag = $(this).data('flag');
    	
    $(".onoffbutton").animate({left: flag ? 1.5 : 37},"fast");
    	
    $(this).data('flag', !flag);
	});

	$('.onoffdivas').click(function(){
       if($(".offbutton").text() == 'On')
       {
           $(".offbutton").text('Off');
       }
       else
       {
           $(".offbutton").text('On');
       }
           });

  
  var krak = $(".contikas")
  var wrap = $("#contas");
  wrap.on("scroll", function(e) { 
  if (this.scrollTop > krak.height()) {
    wrap.addClass("fix-contasafix");
    $(".taxes").addClass("nonius");
  } else {
    wrap.removeClass("fix-contasafix");
    $(".taxes").removeClass("nonius");
  }
  });
  
  

$('.qtyplus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            $('input[name='+fieldName+']').val(currentVal + 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(1);
        }
    });
    // This button will decrement the value till 0
    $(".qtyminus").click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 1) {
            // Decrement one
            $('input[name='+fieldName+']').val(currentVal - 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(1);
        }
    });


    $('.typlus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            $('input[name='+fieldName+']').val(currentVal + 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(0);
        }
    });
    // This button will decrement the value till 0
    $(".tyminus").click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            $('input[name='+fieldName+']').val(currentVal - 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(0);
        }
    });

 $('.yplus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            $('input[name='+fieldName+']').val(currentVal + 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(0);
        }
          $(".yplus").click(function() {
              $(".ty").show();
            });
    });
    // This button will decrement the value till 0
    $(".yminus").click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            $('input[name='+fieldName+']').val(currentVal - 1);
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(0);
        }
        $(".yminus").click(function() {
          $(".ty").hide();
        });


    });
    $(".slides, .slidebutton-left, .slidebutton-right").mouseenter(function() {
      $(".slidebutton-left").css("visibility", "visible");
      $(".slidebutton-right").css("visibility", "visible");
    });
    $(".slides").mouseleave(function() {
      $(".slidebutton-left").css("visibility", "");
      $(".slidebutton-right").css("visibility", "");
    });




    
      
});

function myMap() {
  var mapCanvas = document.getElementById("map");
  var mapOptions = {
    center: new google.maps.LatLng(52.237049, 21.017532),
    zoom: 10
  }
  var map = new google.maps.Map(mapCanvas, mapOptions);
};


var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
    showDivs(slideIndex += n);
}

function showDivs(n) {
    var i;
    var x = document.getElementsByClassName("slides");
    if (n > x.length) {slideIndex = 1}
    if (n < 1) {slideIndex = x.length} ;
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    x[slideIndex-1].style.display = "block";
}


